from django.apps import AppConfig


class SubscribeappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'subscribeapp'
